import PySimpleGUI as sg
import pyttsx3

tts_engine = pyttsx3.init()
voice_types = tts_engine.getProperty('voices')



layout = [    [sg.Text('Select the type of voice:',text_color='black',background_color='white'),sg.Radio('Kwaku', 'RADIO1', default=True, key='Kwaku',background_color='red'),sg.Radio('Afia', 'RADIO1', key='Afia',background_color='green')],
     [sg.Text('Enter text to speak:',text_color='white',background_color='red',)],
          
    [sg.InputText(key='user_input'),sg.Button('Speak',button_color='blue')],
   
    
]

window = sg.Window('HOLLANDIA', layout,background_color='white')

while True:
    event, values = window.read()
    if event == sg.WINDOW_CLOSED:
        break
    elif event == 'Speak':
        text = values['user_input']
        if values['Kwaku']:
            tts_engine.setProperty('voice', voice_types[0].id)
        elif values['Afia']:
           tts_engine.setProperty('voice', voice_types[1].id) 
    
        tts_engine.say(text)
        tts_engine.runAndWait()

window.close()